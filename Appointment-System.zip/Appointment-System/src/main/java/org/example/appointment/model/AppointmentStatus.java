package org.example.appointment.model;

public enum AppointmentStatus{
    Available, Booked;
}
