package org.example.appointment.exception;

public class AppointmentNotFoundException extends Exception{
    public AppointmentNotFoundException(String s) {
        super(s);
    }
}
